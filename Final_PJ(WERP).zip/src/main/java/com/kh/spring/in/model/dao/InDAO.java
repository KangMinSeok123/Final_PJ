package com.kh.spring.in.model.dao;


import com.kh.spring.in.model.vo.InManagement;


public interface InDAO {
	

	int insertIn(InManagement inNum);
}