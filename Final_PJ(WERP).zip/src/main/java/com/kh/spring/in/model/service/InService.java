package com.kh.spring.in.model.service;

import com.kh.spring.in.model.vo.InManagement;

public interface InService {

	int insertIn(InManagement inNum);
}