package com.kh.spring.pd.model.dao;



import com.kh.spring.pd.model.vo.PdVo;




public interface PdDAO {

	int insertPd(PdVo pd);

	
	
	
	
}
