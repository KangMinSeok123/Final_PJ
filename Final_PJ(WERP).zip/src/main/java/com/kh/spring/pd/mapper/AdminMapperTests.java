package com.kh.spring.pd.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.kh.spring.pd.model.vo.PdVo;


// @RunWith(SpringJUnit4ClassRunner.class)
// @Configuration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class AdminMapperTests {
/*
	@Autowired
	private AdminMapper mapper;
	
	/* 상품 등록 * /
	@Test
	public void pdEnrollTest() throws Exception{
		
		PdVo pro = new PdVo();
		
		pro.setPcode("A001");
		pro.setPname("Mac");
		pro.setCategory("Mac-1");
		pro.setInprice(1490000);
		pro.setOutprice(1490000);
		pro.setPdivision("전자제품");
		
		mapper.pdEnroll(pro);
	}
	*/
}
