package com.kh.spring.pd.mapper;

import com.kh.spring.pd.model.vo.PdVo;

public interface AdminMapper {

	public void pdEnroll(PdVo pd);
}
